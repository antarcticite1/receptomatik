# Что приготовить? — Android-приложение

Внутри: все рецепты и фото, работают без интернета. Отметки в холодильнике,
избранное и список покупок сохраняются в телефоне.

## Сборка без программ (через GitHub)
1. Новый репозиторий на github.com (лучше Private).
2. «Add file → Upload files» — загрузите project.zip, нажмите «Commit changes».
3. «Add file → Create new file», имя `.github/workflows/build.yml`, вставьте содержимое
   файла build.yml, «Commit changes».
4. Через 3–5 минут во вкладке «Releases» (справа на главной странице репозитория)
   появится chto-prigotovit.apk.

## Сборка в Android Studio
Откройте эту папку, затем Build → Build App Bundle(s) / APK(s) → Build APK(s),
или в терминале: `./gradlew assembleRelease` → app/build/outputs/apk/release/app-release.apk
