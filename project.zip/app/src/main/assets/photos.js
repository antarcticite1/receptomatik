// Р¤РѕС‚Рѕ Р±Р»СЋРґ Рё СЃСЃС‹Р»РєРё РЅР° РёСЃС‚РѕС‡РЅРёРєРё (СЃРѕР·РґР°С‘С‚СЃСЏ tools/get-photos.ps1)
window.PHOTOS = {
    "borsch":  {
                   "page":  "https://en.wikipedia.org/wiki/Borscht",
                   "file":  "images/borsch.jpg"
               },
    "shchi":  {
                  "page":  "https://en.wikipedia.org/wiki/Shchi",
                  "file":  "images/shchi.jpg"
              },
    "okroshka":  {
                     "page":  "https://en.wikipedia.org/wiki/Okroshka",
                     "file":  "images/okroshka.jpg"
                 },
    "syrniki":  {
                    "page":  "https://en.wikipedia.org/wiki/Syrniki",
                    "file":  "images/syrniki.jpg"
                },
    "bliny":  {
                  "page":  "https://en.wikipedia.org/wiki/Blini",
                  "file":  "images/bliny.jpg"
              },
    "olivier":  {
                    "page":  "https://en.wikipedia.org/wiki/Olivier_salad",
                    "file":  "images/olivier.jpg"
                },
    "stroganoff":  {
                       "page":  "https://en.wikipedia.org/wiki/Beef_Stroganoff",
                       "file":  "images/stroganoff.jpg"
                   },
    "pelmeni":  {
                    "page":  "https://en.wikipedia.org/wiki/Pelmeni",
                    "file":  "images/pelmeni.jpg"
                },
    "kotlety":  {
                    "page":  "https://ru.wikipedia.org/wiki/%D0%9A%D0%BE%D1%82%D0%BB%D0%B5%D1%82%D0%B0",
                    "file":  "images/kotlety.jpg"
                },
    "medovik":  {
                    "page":  "https://en.wikipedia.org/wiki/Medovik",
                    "file":  "images/medovik.jpg"
                },
    "grechka":  {
                    "page":  "https://ru.wikipedia.org/wiki/%D0%93%D1%80%D0%B5%D1%87%D0%BD%D0%B5%D0%B2%D0%B0%D1%8F_%D0%BA%D0%B0%D1%88%D0%B0",
                    "file":  "images/grechka.jpg"
                },
    "ovsyanka":  {
                     "page":  "https://ru.wikipedia.org/wiki/%D0%9E%D0%B2%D1%81%D1%8F%D0%BD%D0%B0%D1%8F_%D0%BA%D0%B0%D1%88%D0%B0",
                     "file":  "images/ovsyanka.jpg"
                 },
    "varenyky":  {
                     "page":  "https://en.wikipedia.org/wiki/Varenyky",
                     "file":  "images/varenyky.jpg"
                 },
    "draniki":  {
                    "page":  "https://ru.wikipedia.org/wiki/%D0%9A%D0%B0%D1%80%D1%82%D0%BE%D1%84%D0%B5%D0%BB%D1%8C%D0%BD%D1%8B%D0%B5_%D0%BE%D0%BB%D0%B0%D0%B4%D1%8C%D0%B8",
                    "file":  "images/draniki.jpg"
                },
    "bibimbap":  {
                     "page":  "https://en.wikipedia.org/wiki/Bibimbap",
                     "file":  "images/bibimbap.jpg"
                 },
    "bulgogi":  {
                    "page":  "https://en.wikipedia.org/wiki/Bulgogi",
                    "file":  "images/bulgogi.jpg"
                },
    "kimchijjigae":  {
                         "page":  "https://en.wikipedia.org/wiki/Kimchi-jjigae",
                         "file":  "images/kimchijjigae.jpg"
                     },
    "japchae":  {
                    "page":  "https://en.wikipedia.org/wiki/Japchae",
                    "file":  "images/japchae.jpg"
                },
    "gyeranmari":  {
                       "page":  "https://en.wikipedia.org/wiki/Gyeran-mari",
                       "file":  "images/gyeranmari.jpg"
                   },
    "morkovcha":  {
                      "page":  "https://ru.wikipedia.org/wiki/%D0%9C%D0%BE%D1%80%D0%BA%D0%BE%D0%B2%D1%8C_%D0%BF%D0%BE-%D0%BA%D0%BE%D1%80%D0%B5%D0%B9%D1%81%D0%BA%D0%B8",
                      "file":  "images/morkovcha.jpg"
                  },
    "kungpao":  {
                    "page":  "https://en.wikipedia.org/wiki/Kung_Pao_chicken",
                    "file":  "images/kungpao.jpg"
                },
    "mapotofu":  {
                     "page":  "https://en.wikipedia.org/wiki/Mapo_tofu",
                     "file":  "images/mapotofu.jpg"
                 },
    "friedrice":  {
                      "page":  "https://en.wikipedia.org/wiki/Fried_rice",
                      "file":  "images/friedrice.jpg"
                  },
    "tomatoegg":  {
                      "page":  "https://en.wikipedia.org/wiki/Stir-fried_tomato_and_scrambled_eggs",
                      "file":  "images/tomatoegg.png"
                  },
    "sweetsour":  {
                      "page":  "https://en.wikipedia.org/wiki/Sweet_and_sour_pork",
                      "file":  "images/sweetsour.jpg"
                  },
    "hotsour":  {
                    "page":  "https://en.wikipedia.org/wiki/Hot_and_sour_soup",
                    "file":  "images/hotsour.jpg"
                },
    "congee":  {
                   "page":  "https://en.wikipedia.org/wiki/Congee",
                   "file":  "images/congee.jpg"
               },
    "miso":  {
                 "page":  "https://en.wikipedia.org/wiki/Miso_soup",
                 "file":  "images/miso.jpg"
             },
    "oyakodon":  {
                     "page":  "https://en.wikipedia.org/wiki/Oyakodon",
                     "file":  "images/oyakodon.jpg"
                 },
    "teriyaki":  {
                     "page":  "https://en.wikipedia.org/wiki/Teriyaki",
                     "file":  "images/teriyaki.jpg"
                 },
    "okonomiyaki":  {
                        "page":  "https://en.wikipedia.org/wiki/Okonomiyaki",
                        "file":  "images/okonomiyaki.jpg"
                    },
    "carbonara":  {
                      "page":  "https://en.wikipedia.org/wiki/Carbonara",
                      "file":  "images/carbonara.jpg"
                  },
    "lasagna":  {
                    "page":  "https://en.wikipedia.org/wiki/Lasagna",
                    "file":  "images/lasagna.jpg"
                },
    "risotto":  {
                    "page":  "https://en.wikipedia.org/wiki/Risotto",
                    "file":  "images/risotto.jpg"
                },
    "frittata":  {
                     "page":  "https://en.wikipedia.org/wiki/Frittata",
                     "file":  "images/frittata.jpg"
                 },
    "minestrone":  {
                       "page":  "https://en.wikipedia.org/wiki/Minestrone",
                       "file":  "images/minestrone.jpg"
                   },
    "tiramisu":  {
                     "page":  "https://en.wikipedia.org/wiki/Tiramisu",
                     "file":  "images/tiramisu.jpg"
                 },
    "crepes":  {
                   "page":  "https://en.wikipedia.org/wiki/Cr%C3%AApe",
                   "file":  "images/crepes.jpg"
               },
    "ratatouille":  {
                        "page":  "https://en.wikipedia.org/wiki/Ratatouille",
                        "file":  "images/ratatouille.jpg"
                    },
    "onionsoup":  {
                      "page":  "https://en.wikipedia.org/wiki/French_onion_soup",
                      "file":  "images/onionsoup.jpg"
                  },
    "plov":  {
                 "page":  "https://ru.wikipedia.org/wiki/%D0%9F%D0%BB%D0%BE%D0%B2",
                 "file":  "images/plov.jpg"
             },
    "chili":  {
                  "page":  "https://en.wikipedia.org/wiki/Chili_con_carne",
                  "file":  "images/chili.jpg"
              },
    "tacos":  {
                  "page":  "https://en.wikipedia.org/wiki/Taco",
                  "file":  "images/tacos.jpg"
              },
    "pancakes":  {
                     "page":  "https://en.wikipedia.org/wiki/Pancake",
                     "file":  "images/pancakes.jpg"
                 },
    "dal":  {
                "page":  "https://en.wikipedia.org/wiki/Dal",
                "file":  "images/dal.png"
            },
    "chana":  {
                  "page":  "https://en.wikipedia.org/wiki/Chana_masala",
                  "file":  "images/chana.jpg"
              },
    "shakshuka":  {
                      "page":  "https://en.wikipedia.org/wiki/Shakshouka",
                      "file":  "images/shakshuka.jpg"
                  },
    "pannacotta":  {
                       "page":  "https://en.wikipedia.org/wiki/Panna_cotta",
                       "file":  "images/pannacotta.jpg"
                   },
    "quiche":  {
                   "page":  "https://en.wikipedia.org/wiki/Quiche",
                   "file":  "images/quiche.jpg"
               },
    "croque":  {
                   "page":  "https://en.wikipedia.org/wiki/Croque_monsieur",
                   "file":  "images/croque.jpg"
               },
    "cremebrulee":  {
                        "page":  "https://en.wikipedia.org/wiki/Cr%C3%A8me_br%C3%BBl%C3%A9e",
                        "file":  "images/cremebrulee.jpg"
                    },
    "kharcho":  {
                    "page":  "https://en.wikipedia.org/wiki/Kharcho",
                    "file":  "images/kharcho.jpg"
                },
    "chakhokhbili":  {
                         "page":  "https://en.wikipedia.org/wiki/Chakhokhbili",
                         "file":  "images/chakhokhbili.jpg"
                     },
    "lobio":  {
                  "page":  "https://en.wikipedia.org/wiki/Lobio",
                  "file":  "images/lobio.jpg"
              },
    "quesadilla":  {
                       "page":  "https://en.wikipedia.org/wiki/Quesadilla",
                       "file":  "images/quesadilla.jpg"
                   },
    "huevos":  {
                   "page":  "https://en.wikipedia.org/wiki/Huevos_rancheros",
                   "file":  "images/huevos.jpg"
               },
    "brownie":  {
                    "page":  "https://en.wikipedia.org/wiki/Chocolate_brownie",
                    "file":  "images/brownie.jpg"
                },
    "cheesecake":  {
                       "page":  "https://en.wikipedia.org/wiki/Cheesecake",
                       "file":  "images/cheesecake.jpg"
                   },
    "macncheese":  {
                       "page":  "https://en.wikipedia.org/wiki/Macaroni_and_cheese",
                       "file":  "images/macncheese.jpg"
                   },
    "butterchicken":  {
                          "page":  "https://en.wikipedia.org/wiki/Butter_chicken",
                          "file":  "images/butterchicken.jpg"
                      },
    "lentilsoup":  {
                       "page":  "https://en.wikipedia.org/wiki/Lentil_soup",
                       "file":  "images/lentilsoup.jpg"
                   },
    "khachapuri":  {
                       "page":  "https://en.wikipedia.org/wiki/Khachapuri",
                       "file":  "images/khachapuri.jpg"
                   },
    "lagman":  {
                   "page":  "https://ru.wikipedia.org/wiki/%D0%9B%D0%B0%D0%B3%D0%BC%D0%B0%D0%BD",
                   "file":  "images/lagman.jpg"
               },
    "vinegret":  {
                     "page":  "https://ru.wikipedia.org/wiki/%D0%92%D0%B8%D0%BD%D0%B5%D0%B3%D1%80%D0%B5%D1%82",
                     "file":  "images/vinegret.jpg"
                 },
    "golubtsy":  {
                     "page":  "https://ru.wikipedia.org/wiki/%D0%93%D0%BE%D0%BB%D1%83%D0%B1%D1%86%D1%8B",
                     "file":  "images/golubtsy.jpg"
                 },
    "ukha":  {
                 "page":  "https://en.wikipedia.org/wiki/Ukha",
                 "file":  "images/ukha.jpg"
             },
    "chickensoup":  {
                        "page":  "https://en.wikipedia.org/wiki/Chicken_soup",
                        "file":  "images/chickensoup.jpg"
                    },
    "napoleon":  {
                     "page":  "https://ru.wikipedia.org/wiki/%D0%9D%D0%B0%D0%BF%D0%BE%D0%BB%D0%B5%D0%BE%D0%BD_(%D1%82%D0%BE%D1%80%D1%82)",
                     "file":  "images/napoleon.jpg"
                 },
    "kimchirice":  {
                       "page":  "https://en.wikipedia.org/wiki/Kimchi_fried_rice",
                       "file":  "images/kimchirice.jpg"
                   },
    "dakgalbi":  {
                     "page":  "https://en.wikipedia.org/wiki/Dak-galbi",
                     "file":  "images/dakgalbi.jpg"
                 },
    "gimbap":  {
                   "page":  "https://en.wikipedia.org/wiki/Gimbap",
                   "file":  "images/gimbap.jpg"
               },
    "chowmein":  {
                     "page":  "https://en.wikipedia.org/wiki/Chow_mein",
                     "file":  "images/chowmein.jpg"
                 },
    "gyudon":  {
                   "page":  "https://en.wikipedia.org/wiki/Gy%C5%ABdon",
                   "file":  "images/gyudon.jpg"
               },
    "tonkatsu":  {
                     "page":  "https://en.wikipedia.org/wiki/Tonkatsu",
                     "file":  "images/tonkatsu.jpg"
                 },
    "onigiri":  {
                    "page":  "https://en.wikipedia.org/wiki/Onigiri",
                    "file":  "images/onigiri.jpg"
                },
    "aglio":  {
                  "page":  "https://en.wikipedia.org/wiki/Spaghetti_aglio_e_olio",
                  "file":  "images/aglio.jpg"
              },
    "margherita":  {
                       "page":  "https://en.wikipedia.org/wiki/Pizza_Margherita",
                       "file":  "images/margherita.jpg"
                   },
    "caprese":  {
                    "page":  "https://en.wikipedia.org/wiki/Caprese_salad",
                    "file":  "images/caprese.jpg"
                },
    "bruschetta":  {
                       "page":  "https://en.wikipedia.org/wiki/Bruschetta",
                       "file":  "images/bruschetta.jpg"
                   },
    "omelette":  {
                     "page":  "https://en.wikipedia.org/wiki/Omelette",
                     "file":  "images/omelette.jpg"
                 },
    "clafoutis":  {
                      "page":  "https://en.wikipedia.org/wiki/Clafoutis",
                      "file":  "images/clafoutis.jpg"
                  },
    "mousse":  {
                   "page":  "https://en.wikipedia.org/wiki/Mousse",
                   "file":  "images/mousse.jpg"
               },
    "khinkali":  {
                     "page":  "https://en.wikipedia.org/wiki/Khinkali",
                     "file":  "images/khinkali.jpg"
                 },
    "ajapsandali":  {
                        "page":  "https://en.wikipedia.org/wiki/Ajapsandali",
                        "file":  "images/ajapsandali.jpg"
                    },
    "shurpa":  {
                   "page":  "https://en.wikipedia.org/wiki/Chorba",
                   "file":  "images/shurpa.jpg"
               },
    "burrito":  {
                    "page":  "https://en.wikipedia.org/wiki/Burrito",
                    "file":  "images/burrito.jpg"
                },
    "caesar":  {
                   "page":  "https://en.wikipedia.org/wiki/Caesar_salad",
                   "file":  "images/caesar.jpg"
               },
    "frenchtoast":  {
                        "page":  "https://en.wikipedia.org/wiki/French_toast",
                        "file":  "images/frenchtoast.jpg"
                    },
    "cookies":  {
                    "page":  "https://en.wikipedia.org/wiki/Chocolate_chip_cookie",
                    "file":  "images/cookies.png"
                },
    "applepie":  {
                     "page":  "https://en.wikipedia.org/wiki/Apple_pie",
                     "file":  "images/applepie.jpg"
                 },
    "burger":  {
                   "page":  "https://en.wikipedia.org/wiki/Hamburger",
                   "file":  "images/burger.jpg"
               },
    "biryani":  {
                    "page":  "https://en.wikipedia.org/wiki/Biryani",
                    "file":  "images/biryani.jpg"
                },
    "hummus":  {
                   "page":  "https://en.wikipedia.org/wiki/Hummus",
                   "file":  "images/hummus.jpg"
               },
    "falafel":  {
                    "page":  "https://en.wikipedia.org/wiki/Falafel",
                    "file":  "images/falafel.jpg"
                },
    "padthai":  {
                    "page":  "https://en.wikipedia.org/wiki/Pad_thai",
                    "file":  "images/padthai.jpg"
                },
    "tomyum":  {
                   "page":  "https://en.wikipedia.org/wiki/Tom_yum",
                   "file":  "images/tomyum.jpg"
               },
    "greencurry":  {
                       "page":  "https://en.wikipedia.org/wiki/Green_curry",
                       "file":  "images/greencurry.jpg"
                   },
    "pho":  {
                "page":  "https://en.wikipedia.org/wiki/Pho",
                "file":  "images/pho.jpg"
            },
    "goicuon":  {
                    "page":  "https://en.wikipedia.org/wiki/G%E1%BB%8Fi_cu%E1%BB%91n",
                    "file":  "images/goicuon.jpg"
                },
    "espanola":  {
                     "page":  "https://en.wikipedia.org/wiki/Spanish_omelette",
                     "file":  "images/espanola.jpg"
                 },
    "gazpacho":  {
                     "page":  "https://en.wikipedia.org/wiki/Gazpacho",
                     "file":  "images/gazpacho.jpg"
                 },
    "paella":  {
                   "page":  "https://en.wikipedia.org/wiki/Paella",
                   "file":  "images/paella.jpg"
               },
    "greeksalad":  {
                       "page":  "https://en.wikipedia.org/wiki/Greek_salad",
                       "file":  "images/greeksalad.jpg"
                   },
    "moussaka":  {
                     "page":  "https://en.wikipedia.org/wiki/Moussaka",
                     "file":  "images/moussaka.jpg"
                 },
    "souvlaki":  {
                     "page":  "https://en.wikipedia.org/wiki/Souvlaki",
                     "file":  "images/souvlaki.jpg"
                 },
    "zapekanka":  {
                      "page":  "https://ru.wikipedia.org/wiki/%D0%97%D0%B0%D0%BF%D0%B5%D0%BA%D0%B0%D0%BD%D0%BA%D0%B0",
                      "file":  "images/zapekanka.jpg"
                  },
    "khaopad":  {
                    "page":  "https://en.wikipedia.org/wiki/Thai_fried_rice",
                    "file":  "images/khaopad.jpg"
                }
};
