window.STEP_PHOTOS = {};
